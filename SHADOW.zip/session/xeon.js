{
	"name": "ŞĦΔĐØŴ Bot Multi Device "
}